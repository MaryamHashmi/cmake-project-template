A dummy cmake project for demonstrating PyPI packaging.
